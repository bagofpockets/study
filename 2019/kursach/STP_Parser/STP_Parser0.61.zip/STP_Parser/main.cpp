﻿// main.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <ctime>
#include "File_handler.h"

int main()
{
	File_handler a("3MBA_N.STP");
	a.get_data();
	
	auto i = a.SURFACE_sorter<SPHERICAL_SURFACE>();
	/*auto j = a.SURFACE_sorter<CONICAL_SURFACE>();
	auto k = a.SURFACE_sorter<TOROIDAL_SURFACE>();
	auto l = a.SURFACE_sorter<CYLINDRICAL_SURFACE>();*/
	auto m = a.B_SPLINE_SURFACE_sorter();


	std::cout << "runtime = " << clock() / 1000.0 << std::endl;
	return 0;
}