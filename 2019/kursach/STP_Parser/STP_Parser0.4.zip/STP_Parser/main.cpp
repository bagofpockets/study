﻿// main.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "File_handler.h"

int main()
{
	File_handler a("MBA_N.STP");

	a.print_data();

	return 0;
}