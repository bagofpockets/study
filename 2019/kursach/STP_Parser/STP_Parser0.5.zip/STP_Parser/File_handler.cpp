#include <iostream>
#include <fstream>
#include <map>
#include <iterator>
#include "File_handler.h"

struct input_data
{
	std::map<unsigned long long, std::string> data;
	std::string type;
};

bool File_handler::initialized(false);

/*-----��������������� �������-----*/

std::string* File_handler::delete_parentheses(std::string* buff)
{
	buff->erase(0, buff->find_first_of('(') + 1); // �������
	buff->pop_back();  // ������� ������

	return buff;
}

unsigned long long File_handler::count_sharps(std::string* buff)
{
	unsigned long long N(0);

	for (size_t i = buff->find_first_of('#'); i <= buff->find_last_of('#'); i++)
	{
		if (buff->at(i) == '#') N++;
	}

	return N;
}

std::string File_handler::get_smth_str_1(const std::string* buff)
{
	size_t first_buffer(buff->find_first_of('\''));
	size_t second_buffer(buff->find_last_of('\'') - first_buffer);

	return buff->substr(first_buffer, second_buffer + 1);
}

std::vector<unsigned long long*>* File_handler::get_associated_ids(std::string* buff, unsigned long long* N)
{
	std::vector<unsigned long long*>* associated_ids_buff(new std::vector<unsigned long long*>);

	for (unsigned long long i = 0; i < *N; i++)
	{
		buff->erase(0, 1);
		if ((buff->find_first_of('#') == 0) || (buff->find_first_of(',') == 0)) buff->erase(0, 1);

		if (buff->find_first_of(',') != std::string::npos)
		{
			size_t first_buffer = buff->find_first_of(',');
			associated_ids_buff->push_back(new unsigned long long(std::stoull(buff->substr(0, first_buffer))));
		}
		else associated_ids_buff->push_back(new unsigned long long(std::stoull(*buff)));

		if (buff->find_first_of('#') != std::string::npos) buff->erase(0, buff->find_first_of('#'));
	}

	return associated_ids_buff;
}

std::string File_handler::get_parentheses_content(const std::string* buff)
{
	size_t first_buffer = buff->find_first_of('(');
	size_t second_buffer = buff->find_first_of(')') - first_buffer;
	std::string ids_buffer = buff->substr(first_buffer, second_buffer);

	return ids_buffer;
}

Support_class* File_handler::get_support_object(const unsigned long long* ID)
{
	Support_class* support_buff(new Support_class);
	std::string buffer;
	size_t first_buffer(0);
	size_t second_buffer(0);

	for (auto i = data_vec->begin(); i != data_vec->end(); ++i)
	{
		if ((((*i)->type == "CARTESIAN_POINT") || ((*i)->type == "DIRECTION")) && ((*i)->data.find(*ID) != (*i)->data.end()))
		{
			support_buff->type = &(*i)->type;

			buffer = (*i)->data[*ID];

			buffer = *delete_parentheses(&buffer);

			*support_buff->smth_str1 = get_smth_str_1(&buffer);

			buffer = get_parentheses_content(&buffer);
			buffer.erase(0, 1);

			second_buffer = buffer.find_first_of(',');
			*support_buff->x = std::stod(buffer.substr(0, second_buffer));

			buffer.erase(0, second_buffer + 1);

			second_buffer = buffer.find_first_of(',');
			*support_buff->y = std::stod(buffer.substr(0, second_buffer));

			buffer.erase(0, second_buffer + 1);

			*support_buff->z = std::stod(buffer);

			break;
		}
	}

	return support_buff;
}

AXIS2_PLACEMENT_3D* File_handler::get_AXIS2_PLACEMENT_3D(const unsigned long long* ID)
{
	AXIS2_PLACEMENT_3D* AXIS2_PLACEMENT_3D_buff(new AXIS2_PLACEMENT_3D);
	std::string buffer;
	size_t first_buffer(0);
	size_t second_buffer(0);
	unsigned long long N_buffer(0);
	unsigned long long Id_buffer(0);

	for (auto i = data_vec->begin(); i != data_vec->end(); ++i)
	{
		if ((*i)->type == "AXIS2_PLACEMENT_3D")
		{
			buffer = (*i)->data[*ID];

			buffer = *delete_parentheses(&buffer);

			N_buffer = count_sharps(&buffer);

			*AXIS2_PLACEMENT_3D_buff->smth_str1 = get_smth_str_1(&buffer);

			buffer.erase(0, buffer.find_first_of('#'));

			for (unsigned long long k = 0; k < N_buffer; k++)
			{
				buffer.erase(0, 1);
				second_buffer = buffer.find_first_of(',');

				Id_buffer = std::stoull(buffer.substr(0, second_buffer));

				for (auto l = data_vec->begin(); l != data_vec->end(); ++l)
				{
					if (((*l)->type == "CARTESIAN_POINT") || ((*l)->type == "DIRECTION"))
					{
						for (auto m = (*l)->data.begin(); m != (*l)->data.end(); ++m)
						{
							if ((*m).first == Id_buffer)
							{
								AXIS2_PLACEMENT_3D_buff->associated_ids->push_back(get_support_object(&Id_buffer));

								break;
							}
						}
					}
				}

				if (buffer.find('#') != std::string::npos) buffer.erase(0, buffer.find_first_of('#'));
			}

			break;
		}
	}

	return AXIS2_PLACEMENT_3D_buff;
}

B_SPLINE_SURFACE* File_handler::get_B_SPLINE_SURFACE(const std::string* buff)
{
	B_SPLINE_SURFACE* B_SPLINE_SURFACE_buff(new B_SPLINE_SURFACE);
	std::string buffer(*buff), sub_buff, ids_buff;
	size_t first_buffer(0);
	size_t second_buffer(0);
	size_t third_buffer(0);
	unsigned long long N_buffer(0);
	unsigned long long Id_buffer(0);
	std::vector<unsigned long long*> associated_ids_buff;
	std::vector<Support_class*>* support_class_vec_buff;

	buffer.erase(0, 1);
	buffer.pop_back();

	second_buffer = buffer.find_first_of(',');
	*B_SPLINE_SURFACE_buff->smth_int1 = std::stoi(buffer.substr(0, second_buffer));

	buffer.erase(0, second_buffer + 1);

	second_buffer = buffer.find_first_of(',');
	*B_SPLINE_SURFACE_buff->smth_int2 = std::stoi(buffer.substr(0, second_buffer));

	buffer.erase(0, second_buffer + 1);

	first_buffer = buffer.find_first_of('(') + 1;
	second_buffer = buffer.find_last_of(')');

	sub_buff = buffer.substr(first_buffer, second_buffer - first_buffer);

	first_buffer = sub_buff.find_first_of('(') + 1;
	third_buffer = sub_buff.find_first_of(')');

	while (third_buffer != std::string::npos)
	{
		ids_buff = sub_buff.substr(first_buffer, third_buffer - first_buffer);
		N_buffer = count_sharps(&ids_buff);
		sub_buff.erase(0, third_buffer + 1);

		associated_ids_buff = *get_associated_ids(&ids_buff, &N_buffer);

		support_class_vec_buff = new std::vector<Support_class*>;

		for (auto i = associated_ids_buff.begin(); i != associated_ids_buff.end(); ++i)
		{
			support_class_vec_buff->push_back(get_support_object(*i));
		}

		B_SPLINE_SURFACE_buff->associated_support_ids->push_back(support_class_vec_buff);

		first_buffer = sub_buff.find_first_of('(') + 1;
		third_buffer = sub_buff.find_first_of(')');
	}

	buffer.erase(0, second_buffer + 2);

	second_buffer = buffer.find_first_of(',');
	*B_SPLINE_SURFACE_buff->smth_str2 = buffer.substr(0, second_buffer);
	buffer.erase(0, second_buffer + 1);

	second_buffer = buffer.find_first_of(',');
	*B_SPLINE_SURFACE_buff->smth_str3 = buffer.substr(0, second_buffer);
	buffer.erase(0, second_buffer + 1);

	second_buffer = buffer.find_first_of(',');
	*B_SPLINE_SURFACE_buff->smth_str4 = buffer.substr(0, second_buffer);
	buffer.erase(0, second_buffer + 1);

	second_buffer = buffer.find_first_of(',');
	*B_SPLINE_SURFACE_buff->smth_str5 = buffer.substr(0, second_buffer);
	buffer.erase(0, second_buffer + 1);

	return B_SPLINE_SURFACE_buff;
}

/*-----������������-----*/

std::vector<CLOSED_SHELL*>* File_handler::CLOSED_SHELL_sorter()
{
	std::vector<CLOSED_SHELL*>* CLOSED_SHELL_vec(new std::vector<CLOSED_SHELL*>);
	std::string buffer;
	size_t first_buffer(0);
	size_t second_buffer(0);
	unsigned long long N_buffer(0);
	CLOSED_SHELL* CLOSED_SHELL_buffer;

	for (auto i = data_vec->begin(); i != data_vec->end(); ++i)
	{
		if ((*i)->type == "CLOSED_SHELL")
		{
			for (auto j = (*i)->data.begin(); j != (*i)->data.end(); ++j)
			{
				buffer = (*j).second;
				N_buffer = count_sharps(&buffer);

				buffer = *delete_parentheses(&buffer);

				CLOSED_SHELL_buffer = new CLOSED_SHELL;

				CLOSED_SHELL_buffer->smth_str1 = &get_smth_str_1(&buffer);

				first_buffer = buffer.find_first_of('\'');
				second_buffer = buffer.find_first_of('(') - first_buffer;

				buffer.erase(first_buffer, second_buffer + 1);
				buffer.pop_back();

				CLOSED_SHELL_buffer->associated_ids = get_associated_ids(&buffer, &N_buffer);

				CLOSED_SHELL_vec->push_back(CLOSED_SHELL_buffer);
			}
		}
	}

	return CLOSED_SHELL_vec;
}

std::vector<ADVANCED_FACE*>* File_handler::ADVANCED_FACE_sorter()
{
	std::vector<CLOSED_SHELL*>* input_CLOSED_SHELL = CLOSED_SHELL_sorter();

	std::vector<ADVANCED_FACE*>* ADVANCED_FACE_vec(new std::vector<ADVANCED_FACE*>);
	std::string buffer;
	std::string ids_buffer;
	size_t first_buffer(0);
	size_t second_buffer(0);
	unsigned long long N_buffer(0);
	ADVANCED_FACE* ADVANCED_FACE_buffer;

	for (auto i = input_CLOSED_SHELL->begin(); i != input_CLOSED_SHELL->end(); ++i)
	{
		for (auto j = (*i)->associated_ids->begin(); j != (*i)->associated_ids->end(); ++j)
		{
			for (auto k = data_vec->begin(); k != data_vec->end(); ++k)
			{
				if ((*k)->type == "ADVANCED_FACE")
				{
					for (auto l = (*k)->data.begin(); l != (*k)->data.end(); ++l)
					{
						if ((*l).first == **j)
						{
							buffer = (*l).second;

							buffer = *delete_parentheses(&buffer);

							N_buffer = count_sharps(&get_parentheses_content(&buffer));

							ADVANCED_FACE_buffer = new ADVANCED_FACE;

							*ADVANCED_FACE_buffer->smth_str1 = get_smth_str_1(&buffer);

							ids_buffer = get_parentheses_content(&buffer);
							*ADVANCED_FACE_buffer->associated_ids = *get_associated_ids(&ids_buffer, &N_buffer);

							first_buffer = buffer.find_first_of(')');
							buffer.erase(0, first_buffer);

							first_buffer = buffer.find_first_of('#');
							buffer.erase(0, first_buffer);

							first_buffer = buffer.find_first_of(',');
							second_buffer = buffer.find_first_of('#');

							*ADVANCED_FACE_buffer->associated_id = std::stoull(buffer.substr(1, first_buffer - second_buffer - 1));

							first_buffer = buffer.find_first_of('#');
							buffer.erase(0, first_buffer);

							first_buffer = buffer.find_first_of(',') + 1;
							buffer.erase(0, first_buffer);

							*ADVANCED_FACE_buffer->smth_str2 = buffer;

							ADVANCED_FACE_vec->push_back(ADVANCED_FACE_buffer);

							break;
						}
					}
					break;
				}

			}
		}
	}

	return ADVANCED_FACE_vec;
}

std::vector<input_data*>* File_handler::COMPLEX_sorter(const unsigned long long* ID)
{
	std::vector<input_data*>* COMPLEX_vec(new std::vector<input_data*>);
	std::string buffer, sub_buff, properties;
	size_t first_buffer(0);
	size_t second_buffer(0);

	for (auto i = data_vec->begin(); i != data_vec->end(); ++i)
	{
		if ((*i)->type == "COMPLEX")
		{
			buffer = (*i)->data[*ID];

			buffer = *delete_parentheses(&buffer);
			buffer.erase(0, 1);

			if (buffer.find("B_SPLINE_SURFACE") != std::string::npos) while (buffer.find_first_of('\n') != std::string::npos)
			{
				if (buffer.find_first_of('\n') == 0) buffer.erase(0, 1);
				sub_buff = buffer.substr(0, buffer.find_first_of('\n'));

				first_buffer = sub_buff.find_first_of('(');
				second_buffer = sub_buff.find_last_of(')');

				if (first_buffer != std::string::npos)
				{
					if ((first_buffer > sub_buff.find_first_of(')')) || (sub_buff[first_buffer + 1] == '#'))
					{
						if ((sub_buff[second_buffer + 1] == ',')) properties += sub_buff;
						else data_buffer->data[*ID] += sub_buff.substr(0, second_buffer + 1);
					}
					else
					{
						data_buffer = new input_data;

						if (sub_buff[sub_buff.length()] != ')') data_buffer->type = sub_buff.substr(0, first_buffer);

						if (second_buffer != std::string::npos)
						{
							if (second_buffer != sub_buff.length()) properties = sub_buff.substr(first_buffer, sub_buff.length() - first_buffer + 1);
							else properties = sub_buff.substr(first_buffer, second_buffer - first_buffer + 1);
						}
						else properties = sub_buff;

						data_buffer->data.insert(std::pair<unsigned long long, std::string>(*ID, properties));

						COMPLEX_vec->push_back(data_buffer);
					}
				}
				else data_buffer->data[*ID] += sub_buff.substr(0, second_buffer + 1);

				buffer.erase(0, sub_buff.length());
			}

			break;
		}
	}
	return COMPLEX_vec;
}

template <class SURFACE>
std::vector<SURFACE*>* File_handler::SURFACE_sorter()
{
	std::vector<ADVANCED_FACE*>* input_ADVANCED_FACE = ADVANCED_FACE_sorter();

	std::vector<SURFACE*>* SURFACE_vec(new std::vector<SURFACE*>);
	std::string buffer;
	size_t first_buffer(0);
	size_t second_buffer(0);
	double* smth_d_buff;
	unsigned long long Id_buffer(0);
	SURFACE* SURFACE_buffer;

	for (auto i = input_ADVANCED_FACE->begin(); i != input_ADVANCED_FACE->end(); ++i)
	{
		for (auto j = data_vec->begin(); j != data_vec->end(); ++j)
		{
			if ("class " + (*j)->type == typeid(SURFACE).name())
			{
				for (auto k = (*j)->data.begin(); k != (*j)->data.end(); ++k)
				{
					if ((*k).first == *(*i)->associated_id)
					{
						buffer = (*k).second;

						buffer = *delete_parentheses(&buffer);

						SURFACE_buffer = new SURFACE;

						*SURFACE_buffer->smth_str1 = get_smth_str_1(&buffer);

						buffer.erase(0, buffer.find_first_of(',') + 1);

						first_buffer = buffer.find_first_of('#') + 1;
						second_buffer = buffer.find_first_of(',') - first_buffer;

						Id_buffer = std::stoull(buffer.substr(first_buffer, second_buffer));
						SURFACE_buffer->AXIS2_PLACEMENT_3D_data = get_AXIS2_PLACEMENT_3D(&Id_buffer);

						buffer.erase(0, buffer.find_first_of(',') + 1);
						first_buffer = buffer.find_first_of(',');

						smth_d_buff = new double(std::stod(buffer.substr(0, first_buffer)));
						SURFACE_buffer->smth_d.push_back(smth_d_buff);

						buffer.erase(0, buffer.find_first_of(',') + 1);
						first_buffer = buffer.find_first_of(',');

						if (((*j)->type == "CONICAL_SURFACE") || ((*j)->type == "TOROIDAL_SURFACE"))
						{
							smth_d_buff = new double(std::stod(buffer.substr(0, first_buffer)));
							SURFACE_buffer->smth_d.push_back(smth_d_buff);
						}

						SURFACE_vec->push_back(SURFACE_buffer);
					}
				}
			}
		}
	}

	return SURFACE_vec;
}

template <class SURFACE>
void File_handler::print_SURFACE(std::vector<SURFACE*> V)
{
	for (auto i = V.begin(); i != V.end(); ++i)
	{
		std::cout << *(*i)->smth_str1 << std::endl;
		for (auto j = (*i)->AXIS2_PLACEMENT_3D_data->associated_ids->begin(); j < (*i)->AXIS2_PLACEMENT_3D_data->associated_ids->end(); ++j)
		{
			std::cout << *(*j)->type << " " << *(*j)->smth_str1 << " " << *(*j)->x << " " << *(*j)->y << " " << *(*j)->z << std::endl;
		}
		for (auto j = (*i)->smth_d.begin(); j != (*i)->smth_d.end(); ++j)
		{
			std::cout << **j << " ";
		}
		std::cout << std::endl;
		std::cout << std::endl;
	}
	return;
}

std::vector<B_SPLINE_SURFACE*>* File_handler::B_SPLINE_SURFACE_sorter()
{
	std::vector<ADVANCED_FACE*>* input_ADVANCED_FACE = ADVANCED_FACE_sorter();
	std::vector<input_data*> input_COMPLEX;

	std::vector<B_SPLINE_SURFACE*>* B_SPLINE_SURFACE_vec(new std::vector<B_SPLINE_SURFACE*>);
	std::string buffer;

	for (auto i = input_ADVANCED_FACE->begin(); i != input_ADVANCED_FACE->end(); ++i)
	{
		for (auto j = data_vec->begin(); j != data_vec->end(); ++j)
		{
			if ((*j)->type == "COMPLEX")
			{
				for (auto k = (*j)->data.begin(); k != (*j)->data.end(); ++k)
				{
					if ((*k).first == *(*i)->associated_id)
					{
						input_COMPLEX = *COMPLEX_sorter(&(*k).first);

						for (auto l = input_COMPLEX.begin(); l != input_COMPLEX.end(); ++l)
						{
							if ((*l)->type == "B_SPLINE_SURFACE")
							{
								for (auto m = (*l)->data.begin(); m != (*l)->data.end(); ++m)
								{
									buffer = (*m).second;

									B_SPLINE_SURFACE_vec->push_back(get_B_SPLINE_SURFACE(&buffer));
								}
							}
						}

						break;
					}
				}
				break;
			}
		}
	}

	return B_SPLINE_SURFACE_vec;
}

File_handler::File_handler(std::string input_file_name) : input_file(new std::ifstream), data_vec(new std::vector<input_data*>), data_buffer(NULL)
	{
		input_file->open(input_file_name);
	}

File_handler::~File_handler()
	{
		input_file->close();

		for (auto i = data_vec->begin(); i != data_vec->end(); ++i)
		{
			delete (*i);
			*i = 0;
		}

		delete data_vec;
		delete input_file;
	}

void File_handler::get_data()
	{
		if (input_file->is_open())
		{
			size_t* pos(new size_t(0));
			std::string* input_buffer(new std::string);
			bool flag(false);
			std::string type_buff;
			unsigned long long id_buff(0);

			while (getline(*input_file, *input_buffer, ';'))
			{
				if (input_buffer->length() > 1) if (input_buffer->at(1) == '#')
				{
					input_buffer->erase(1, 1);

					*pos = input_buffer->find_first_of('=');

					id_buff = std::stoull(input_buffer->substr(1, *pos));
					input_buffer->erase(1, *pos);

					*pos = input_buffer->find_first_of('(') - 1;

					if (*pos > 0)
					{
						type_buff = input_buffer->substr(1, *pos);
						input_buffer->erase(1, *pos);
					}
					else
					{
						type_buff = "COMPLEX";
					}

					flag = false;
					if (data_vec->empty())
					{
						data_buffer = new input_data;
						data_buffer->type = type_buff;
						data_vec->push_back(data_buffer);
					}
					for (auto i = data_vec->begin(); i != data_vec->end(); ++i)
					{
						if ((*i)->type == type_buff)
						{
							(*i)->data.insert(std::pair<unsigned long long, std::string>(id_buff, *input_buffer));
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						data_buffer = new input_data;
						data_buffer->type = type_buff;
						data_buffer->data.insert(std::pair<unsigned long long, std::string>(id_buff, *input_buffer));
						data_vec->push_back(data_buffer);
					}
				}
			}

			delete pos;
			delete input_buffer;

			initialized = true;
			return;
		}
		else
		{
			std::cout << "Can't open file" << std::endl;
			return;
		}
	}

void File_handler::print_data(std::string CLASS)
	{
		/*-----����� ����������� �����-----*/
		if (!initialized)
		{
			initialized = true;
			get_data();
		}

		if (CLASS == "CONICAL_SURFACE")
		{
			std::vector<CONICAL_SURFACE*> v0 = *SURFACE_sorter<CONICAL_SURFACE>(); //#538 � #1155
			std::cout << "\tConical surfaces:" << std::endl;
			print_SURFACE(v0);
		}

		if (CLASS == "TOROIDAL_SURFACE")
		{
			std::vector<TOROIDAL_SURFACE*> v1 = *SURFACE_sorter<TOROIDAL_SURFACE>();
			std::cout << "\tToroidal surfaces:" << std::endl;
			print_SURFACE(v1);
		}

		if (CLASS == "CYLINDRICAL_SURFACE")
		{
			std::vector<CYLINDRICAL_SURFACE*> v2 = *SURFACE_sorter<CYLINDRICAL_SURFACE>();
			std::cout << "\tCylindrical surfaces:" << std::endl;
			print_SURFACE(v2);
		}

		if (CLASS == "SPHERICAL_SURFACE")
		{
			std::vector<SPHERICAL_SURFACE*> v3 = *SURFACE_sorter<SPHERICAL_SURFACE>();
			std::cout << "\tSpherical surfaces:" << std::endl;
			print_SURFACE(v3);
		}
		
		if (CLASS == "B_SPLINE_SURFACE")
		{
			std::vector<B_SPLINE_SURFACE*> v4 = *B_SPLINE_SURFACE_sorter(); //#975, #1001, #1191 � #2056
			std::cout << "\n\tB-spline surfaces:" << std::endl;
			for (auto i = v4.begin(); i != v4.end(); ++i)
			{
				std::cout << *(*i)->smth_int1 << " " << *(*i)->smth_int2 << std::endl;

				for (auto j = (*i)->associated_support_ids->begin(); j != (*i)->associated_support_ids->end(); ++j)
				{
					for (auto k = (*j)->begin(); k != (*j)->end(); ++k)
					{
						std::cout << *(*k)->type << " " << *(*k)->smth_str1 << " " << *(*k)->x << " " << *(*k)->y << " " << *(*k)->z << std::endl;
					}
				}

				std::cout << *(*i)->smth_str2 << " " << *(*i)->smth_str3 << " " << *(*i)->smth_str4 << " " << *(*i)->smth_str5 << std::endl;
				std::cout << std::endl;
			}
		}

		return;
	}